<?php
$conn= mysqli_connect("localhost","id8741372_shivani","shivani123","id8741372_cmsdatabase");
?>