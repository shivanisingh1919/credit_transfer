<html>
<head>
<link rel="stylesheet" href="mystyle.css">
</head>
<body>
<center><h1> WELCOME TO MY WEBSITE </h1><br></center>
<ul>
  <li><a class="active" href="INDEX.PHP">Home</a></li>
  <li><a href="view.php">VIEW ALL USERS</a></li>
</ul>
<br>

<CENTER><h2> BEST WEBSITE TO TRANSFER YOUR CREDIT </h2></center>
      <table align="left" cellpadding ="15px">
          <tr>
          <td rowspan="2"><div class ="zoom"><img src="img4.jpg"  height="400" width="550"></div></td>
          <td><div class="zoom"><img src="img2.jpg" id=" height="200" width="450 "></div></td>
          </tr>
          <tr>
          <td><div class="zoom"><img src="img3.jpg" id="i3" height="200" width="450" ></div></td>
          </tr>
      </table>
</html>


