-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 14, 2019 at 12:42 PM
-- Server version: 5.0.41-community-nt
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `credit_transfer`
--

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE IF NOT EXISTS `transfer` (
  `from_user` varchar(10) default NULL,
  `to_user` varchar(10) default NULL,
  `amount` float default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE IF NOT EXISTS `user_data` (
  `name` varchar(20) default NULL,
  `email` varchar(30) default NULL,
  `current_credit` float default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`name`, `email`, `current_credit`) VALUES
('user1', 'user1@gmail.com', 8318),
('user2', 'user2@gmail.com', 12202),
('user3', 'user3@gmail.com', 9750),
('user4', 'user4@gmail.com', 12380),
('user5', 'user5@gmail.com', 39550),
('user6', 'user6@gmail.com', 37390),
('user7', 'user7@gmail.com', 37559),
('user8', 'user8@gmail.com', 21669),
('user9', 'user9@gmail.com', 100980),
('user10', 'user10@gmail.com', 4020);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
