<html>
<head>
<link rel="stylesheet" href="mystyle.css">
<form method="post" action="transfer.php">
</head>
<body>
<ul>
  <li><a class="active" href="INDEX.PHP">Home</a></li>
  <li><a href="view.php">VIEW ALL USERS</a></li>
</ul>
<br>
<center><h2> Enter the amount you want to transfer</h2>
<input type="text" name="amount" size="30"><br><br>
<input type="submit" value="Transfer" name="finaltransfer"></center>";
<?php
session_start();
$conn= mysqli_connect("localhost","root","","credit_transfer");
if(!$conn)
{
	die("connection can' be established");
}


if(isset($_POST['finaltransfer']))
{
	if(isset($_POST['amount']))
           {
			   $amt=$_POST['amount'];
			   if(($_POST['amount'])<1)
			   {
				  echo"<script>alert('Please enter valid amount')</script>";
			   }
			   $creditquery="select current_credit from user_data where name='".$_SESSION['selectfrom']."'";
			   $cred=mysqli_query($conn,$creditquery);
			   $credit=mysqli_fetch_assoc($cred)["current_credit"];
				if($credit<$amt)
				{
				   echo "<script> alert('not sufficient balance to transfer')</script>";
				}
			        else
			            {
							$query="insert into transfer values('".$_SESSION['selectfrom']."','".$_SESSION['selectto']."',".$_POST['amount'].")";
							$result=mysqli_query($conn,$query);
							$fromupdatequery="update user_data set current_credit=current_credit-$amt where name='".$_SESSION['selectfrom']."'";
							$fromupdate=mysqli_query($conn,$fromupdatequery);
							$toupdatequery="update user_data set current_credit=current_credit+$amt where name='".$_SESSION['selectto']."'";
							$toupdate=mysqli_query($conn,$toupdatequery);
							echo"<script> alert('amount transferred succesfully')</script>";
						}
           }
		   
}

?>
</form>
</html>