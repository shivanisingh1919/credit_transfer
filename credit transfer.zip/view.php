<html>
<head>
<link rel="stylesheet" href="mystyle.css">
<form method="post" action="#">
</head>
<body>
<ul>
  <li><a class="active" href="INDEX.PHP">Home</a></li>
  <li><a href="view.php">VIEW ALL USERS</a></li>
</ul>
<h1>HAVE A LOOK AT USERS</h1>
<CENTER><h2>YOU MAY TRANSFER  CREDIT NOW</H2></CENTER>
<br>
<center>
<input type="submit" value="TRANSFER CREDIT" name=transfer align=right>
</center>
<br>
<?php
$conn= mysqli_connect("localhost","root","","credit_transfer");
if(!$conn)
{
	die("connection can' be established");
}

    echo"<center>";
	echo "<table border=5>";
	ECHO"<tr><th>FROM</th>";
	echo "<th>TO</th>";
	echo "<th><U>NAME</th>";
	echo "<th><U>EMAIL-ID</th>";
	echo "<th><U>CURRENT CREDIT</th></tr>";
	
	$query="select*from user_data;";
	$result=mysqli_query($conn,$query);
	while($row=mysqli_fetch_assoc($result))
	{
		echo "<tr>";
		echo "<td><input type= 'radio' name='selectfrom' value ='".$row['name']."'";
        echo "></td>";
        echo "<td><input type= 'radio' name='selectto' value =".$row['name']." ></td>";
		echo "<td>".$row['name']."</td>";
		echo "<td>".$row['email']."</td>";
		echo "<td>".$row['current_credit']."</td></tr>";
	}
	echo "</table>";

	
		echo "</center>";

	if ((isset($_POST['selectfrom'])) && (isset($_POST['selectto'])))
	{
		
		if(isset($_POST['transfer']))
		{
			if($_POST["selectfrom"]==$_POST["selectto"]){
            echo"<script> alert('invalid')</script>";
          }
		  else
           {
			  session_start();
	          $_SESSION['selectfrom']=$_POST['selectfrom'];
	          $_SESSION['selectto']=$_POST['selectto'];
		      header("location:transfer.php");
		   }
	    }
	}
	
?>
</form>
</html>

























